# geometry-genius-resources

### Click here to [Create Private Repo](https://classroom.github.com/a/6nRSQFlh)
Private Repo Link: [https://classroom.github.com/a/6nRSQFlh](https://classroom.github.com/a/6nRSQFlh)
