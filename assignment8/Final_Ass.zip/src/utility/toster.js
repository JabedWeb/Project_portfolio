import { toast } from "react-toastify"


export const toaster = () => {
   toast.warn('Item already bookmarked')
}